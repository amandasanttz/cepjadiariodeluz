import { useState } from 'react';
import { Sparkles } from 'lucide-react';
import logo from 'figma:asset/faae0e0eaa009d050db2f6397b7e0342d710507d.png';

export default function App() {
  const [currentMessage, setCurrentMessage] = useState<string>('');
  const [showMessage, setShowMessage] = useState(false);

  const messages = [
    "Oxalá, o Orixá da criação e pai de todos os Orixás, ensina-nos a pureza e a paciência. Conta a tradição que ele foi injustamente preso por sete anos, mas manteve sua dignidade e fé. Ao ser libertado, perdoou seus opressores, mostrando que o verdadeiro poder está no perdão e na paz interior. Cultive a paciência em seus desafios.",
    "Allan Kardec nos ensina: 'Nascer, morrer, renascer ainda e progredir sempre, tal é a lei'. A reencarnação é uma oportunidade divina de evolução espiritual. Cada vida traz lições necessárias para o aperfeiçoamento da alma. Aceite seus desafios como degraus em sua jornada evolutiva.",
    "Iemanjá, a mãe de todos os Orixás, acolheu os filhos de Oxalá quando ele foi preso. Ela representa o amor maternal incondicional, que acolhe sem julgar. Como as águas do mar, ela nos ensina a dissolver mágoas e renovar energias. Permita-se ser curado pelo amor maternal do universo.",
    "O Livro dos Espíritos nos revela: 'Fora da caridade não há salvação'. A caridade verdadeira não é apenas material, mas está em pensamentos, palavras e ações benevolentes. Cada gesto de amor eleva sua vibração espiritual e aproxima você de Deus. Pratique a caridade em todas as suas formas.",
    "Ogum, o guerreiro divino, trabalhou incansavelmente abrindo caminhos na mata para que a civilização pudesse florescer. Ele nos ensina que o verdadeiro guerreiro luta com honra, protege os fracos e nunca desiste diante das adversidades. Sua espada corta demandas, mas seu coração guarda a justiça. Seja forte, mas justo.",
    "Allan Kardec afirma: 'O Espiritismo vem, no tempo marcado, trazer a consolação suprema'. A dor e o sofrimento têm propósito em nossa evolução. Os desafios são provas que você mesmo escolheu antes de encarnar. Confie que você tem a força necessária para superá-los, pois Deus não dá fardos maiores que podemos carregar.",
    "Xangô, o Rei de Oyó, era tão sábio que quando precisava julgar, ouvia todos os lados antes de decidir. Certa vez, abdicou do trono para buscar a verdade. Ele nos ensina que a verdadeira justiça vem da sabedoria, não da força. Antes de julgar, procure compreender. A paciência é a mãe da sabedoria.",
    "Oxóssi, o caçador divino, nunca caça mais do que precisa, honrando a abundância da natureza. Ele conhece cada planta medicinal da floresta e compartilha esse conhecimento. Ensina-nos que a verdadeira fartura não está em acumular, mas em saber que o universo sempre provê. Confie na providência divina.",
    "O Evangelho Segundo o Espiritismo nos diz: 'Bem-aventurados os aflitos, porque serão consolados'. Toda dor tem um propósito evolutivo. Os espíritos superiores acompanham suas lágrimas e transformam seu sofrimento em luz. A consolação virá quando a lição for aprendida. Tenha fé na justiça divina.",
    "Oxum, a deusa do ouro e dos rios, salvou a humanidade quando todos os Orixás masculinos falharam. Ela nos ensina que a força feminina está na doçura que conquista, na diplomacia que resolve e no amor que transforma. O verdadeiro poder não precisa gritar. Cultive a gentileza como sua maior arma.",
    "Allan Kardec revela: 'Reconhece-se o verdadeiro espírita pela sua transformação moral'. Não basta estudar, é preciso praticar. A evolução espiritual se manifesta em ações concretas de amor, perdão e caridade. Observe seus pensamentos, palavras e atos. Você está evoluindo?",
    "Iansã, senhora dos ventos e tempestades, dançou entre os espíritos sem medo. Ela transformou a morte em passagem sagrada. Ensina-nos que as mudanças, por mais assustadoras que pareçam, são necessárias para o crescimento. Não tema recomeçar. Toda transformação traz renovação.",
    "Nanã Buruquê, a mais antiga das divindades, guarda o mistério da criação da vida no barro sagrado. Ela nos ensina o respeito aos ancestrais e à sabedoria dos mais velhos. Cada rugas conta uma história, cada cicatriz ensina uma lição. Honre seu passado, pois ele construiu seu presente.",
    "O conceito espírita de Lei de Causa e Efeito nos mostra que somos arquitetos de nosso destino. Cada ação gera uma reação, cada pensamento cria uma realidade. Não somos vítimas do acaso, mas criadores de nossa jornada. Plante hoje o que deseja colher amanhã.",
    "Omulu, o médico dos pobres, carrega em seu corpo as marcas da varíola que curou. Coberto por palha, ele esconde suas cicatrizes, mas não sua compaixão. Ensina-nos que nossas feridas nos tornam capazes de curar outros. Sua dor tem propósito: fazer de você um instrumento de cura.",
    "Preto-Velho, em sua sabedoria, diz: 'Tem que ter fé, meu filho, porque sem fé não se vai a lugar nenhum'. Essas entidades que viveram na escravidão ensinam que a verdadeira liberdade é espiritual. Nenhuma corrente prende a alma que confia em Deus. A humildade é o caminho para a verdadeira elevação.",
    "Allan Kardec explica: 'A prece é uma invocação, mediante a qual o homem entra em comunicação com o ser a quem se dirige'. Ore não apenas pedindo, mas agradecendo e vibrando amor. A prece sincera eleva sua frequência e atrai espíritos de luz. Faça da oração um diálogo diário com o divino.",
    "Oxumarê, o arco-íris que liga céu e terra, passa seis meses como homem e seis como mulher. Ele nos ensina que somos seres completos, com aspectos masculinos e femininos em equilíbrio. Aceite todas as suas facetas. A dualidade não é conflito, mas complementaridade.",
    "Caboclo, o espírito do índio brasileiro, traz a força da mata e a sabedoria da terra. Eles trabalham em silêncio, curando com ervas e orações. Ensinam que a verdadeira riqueza está na simplicidade, na conexão com a natureza e no respeito por todas as formas de vida. Volte às suas raízes.",
    "O Espiritismo nos revela que não estamos sós: temos guias espirituais que nos acompanham desde antes do nascimento. Seu anjo de guarda conhece seu plano evolutivo e trabalha incansavelmente para que você o cumpra. Aprenda a ouvir a voz suave da intuição. É seu guia falando.",
    "Exu, o guardião das encruzilhadas, não é demônio, mas mensageiro divino. Ele testa nossa fé, questiona nossa certeza e nos mostra que todo caminho tem consequências. Antes de escolher uma direção, reflita. Exu ensina que o livre-arbítrio vem acompanhado de responsabilidade.",
    "A Lei do Amor, suprema lei universal segundo Kardec, nos diz: 'Amai-vos uns aos outros'. Este é o mandamento que resume toda a evolução espiritual. O amor cura, transforma, eleva e liberta. Onde há amor verdadeiro, não há espaço para ódio, inveja ou mágoa. Seja amor.",
    "Erê, o espírito de criança, nos lembra que devemos manter a pureza e a alegria do coração infantil. Jesus disse que é necessário nascer de novo para entrar no reino dos céus. Isso significa recuperar a inocência, a capacidade de maravilhar-se e a fé sem questionamentos. Permita-se brincar e ser feliz.",
    "Os médiuns são instrumentos da espiritualidade, não donos de poderes especiais. Allan Kardec alerta que a mediunidade é uma faculdade a serviço da caridade, nunca do orgulho ou lucro. Se você tem essa sensibilidade, use-a com humildade e responsabilidade para ajudar, consolar e esclarecer.",
    "Ossaim, o senhor das folhas sagradas, guarda o segredo de cada planta medicinal. Ele nos ensina que a cura está na natureza, que Deus colocou remédio para cada mal na terra. Respeite o poder das ervas e da natureza. O conhecimento ancestral das plantas é sagrado e poderoso.",
    "O perdão é libertação, não apenas para quem é perdoado, mas principalmente para quem perdoa. Allan Kardec nos ensina que guardar rancor é carregar correntes. Perdoar é cortar esses laços e permitir que ambas as almas evoluam. Liberte-se perdoando quem lhe feriu.",
    "Logun-Edé, filho de Oxóssi e Oxum, vive seis meses na mata e seis nos rios, unindo as qualidades do pai e da mãe. Ele nos ensina a versatilidade e a capacidade de adaptação. A vida exige que sejamos guerreiros e gentis, fortes e sensíveis. Equilibre seus opostos internos.",
    "A reencarnação não é castigo, mas oportunidade. Allan Kardec explica que escolhemos nossas provas antes de nascer, com orientação de mentores espirituais. Você escolheu sua família, seus desafios e oportunidades. Tudo faz parte do seu plano evolutivo. Nada é por acaso.",
    "Obá, a guerreira que cortou a própria orelha por amor a Xangô, nos ensina sobre os perigos da devoção cega e da manipulação. Ela aprendeu que o amor verdadeiro não exige sacrifícios dolorosos. Valorize-se. Nenhum amor que exige autodestruição é divino.",
    "Ewá, a senhora da visão espiritual, vive nas nascentes dos rios. Ela nos ensina a clareza de propósito e a pureza de intenções. Antes de agir, purifique seus pensamentos. Antes de falar, limpe suas palavras. A fonte pura gera águas cristalinas. Seja a nascente de boas ações.",
    "A Lei de Ação e Reação não é vingança divina, mas equilíbrio universal. Allan Kardec explica que sofremos não porque Deus pune, mas porque precisamos aprender. Cada dor que causamos, sentiremos; cada alegria que demos, receberemos. Seja responsável por suas ações.",
    "Ibeji, os gêmeos sagrados, representam a dualidade da vida: alegria e tristeza, luz e sombra, ganho e perda. Eles nos ensinam que a vida é feita de opostos complementares. Aceite que após a noite vem o dia, após a tempestade vem a bonança. Tudo é cíclico e passageiro.",
    "A caridade material sem elevação espiritual é incompleta. Allan Kardec nos alerta: de nada adianta dar pão se oferecemos com orgulho ou esperando retorno. A verdadeira caridade é anônima, desinteressada e feita com amor. Doe sem esperar reconhecimento.",
    "Tempo, o orixá que rege o tempo e o destino, nos lembra que tudo tem sua hora certa. Não adianta apressar processos que precisam de maturação. A pressa é inimiga da perfeição. Confie no tempo divino. Quando for a hora certa, as portas se abrirão.",
    "O Livro dos Médiuns nos ensina que os espíritos obsessores não têm poder sobre quem se mantém em vibração elevada. A prece, a vigilância dos pensamentos e a prática do bem são escudos poderosos. Você atrai o que vibra. Eleve sua frequência e afaste as trevas.",
    "Pomba-Gira, incompreendida por muitos, é a força feminina liberta de amarras sociais. Ela não é má, mas ensina o empoderamento e a quebra de padrões limitantes. Respeite sua essência feminina, seja livre para ser quem você é. A verdadeira força feminina não pede permissão.",
    "Allan Kardec conclui que o objetivo da vida é a felicidade, mas não a felicidade egoísta e passageira. A verdadeira felicidade vem do amor, da caridade, do perdão e da paz interior. Busque a felicidade que eleva, não a que aprisiona nos vícios e ilusões materiais.",
    "A Umbanda Sagrada une o melhor do conhecimento espírita, da sabedoria africana e da fé cristã. Ela ensina que todos os caminhos que levam ao amor, à caridade e à evolução são sagrados. Respeite todas as religiões, pois todas buscam Deus. O nome pode mudar, mas a essência é una.",
    "Benzedeiras e benzedeiros são instrumentos de cura pela fé. Com ramos de arruda e orações simples, canalizam energias de cura. Eles nos ensinam que o poder está na fé, não em rituais complicados. A simplicidade e a intenção pura abrem portais de bênçãos. Creia no poder da oração.",
    "O maior ensinamento espiritual é: você é um espírito imortal em jornada evolutiva. O corpo é temporário, as dores são passageiras, mas sua essência é eterna. Invista na evolução do espírito, cultive virtudes, pratique o bem. Isso é o único patrimônio que você levará quando partir."
  ];

  const getRandomMessage = () => {
    const randomIndex = Math.floor(Math.random() * messages.length);
    setCurrentMessage(messages[randomIndex]);
    setShowMessage(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-950 flex items-center justify-center p-8 relative overflow-hidden">
      {/* Elementos decorativos de fundo */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-10">
        <div className="absolute top-20 left-10 text-white animate-pulse">
          <Sparkles size={60} />
        </div>
        <div className="absolute bottom-32 right-20 text-blue-200 animate-pulse" style={{ animationDelay: '1s' }}>
          <Sparkles size={80} />
        </div>
        <div className="absolute top-1/2 right-10 text-white animate-pulse" style={{ animationDelay: '2s' }}>
          <Sparkles size={50} />
        </div>
        <div className="absolute top-1/3 left-1/4 text-blue-300 animate-pulse" style={{ animationDelay: '1.5s' }}>
          <Sparkles size={40} />
        </div>
      </div>

      <div className="max-w-4xl w-full text-center relative z-10">
        {/* Logo */}
        <div className="mb-6 flex justify-center">
          <img src={logo} alt="CEPJA Logo" className="w-32 h-32 object-contain animate-fadeIn" />
        </div>

        {/* Título */}
        <div className="mb-10">
          <h1 className="text-white mb-4 tracking-wide drop-shadow-lg">
            CEPJA DIÁRIO DE LUZ
          </h1>
          <div className="flex items-center justify-center gap-3 mb-2">
            <div className="h-px w-16 bg-gradient-to-r from-transparent via-blue-300 to-blue-400"></div>
            <p className="text-blue-200 tracking-wider">
              Inspire-se na força da Umbanda Sagrada
            </p>
            <div className="h-px w-16 bg-gradient-to-l from-transparent via-blue-300 to-blue-400"></div>
          </div>
        </div>

        {/* Botão */}
        <div className="mb-12">
          <button
            onClick={getRandomMessage}
            className="group px-14 py-7 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-full shadow-2xl hover:shadow-blue-500/50 transition-all duration-300 hover:scale-105 border-2 border-blue-400/30"
          >
            <span className="tracking-wide flex items-center gap-3 justify-center">
              <Sparkles className="group-hover:rotate-12 transition-transform duration-300" size={24} />
              Receber minha Mensagem
              <Sparkles className="group-hover:-rotate-12 transition-transform duration-300" size={24} />
            </span>
          </button>
        </div>

        {/* Área da mensagem */}
        {showMessage && (
          <div className="animate-fadeIn">
            <div className="relative bg-white/95 backdrop-blur-sm rounded-3xl p-10 shadow-2xl border-2 border-blue-300/40 animate-slideUp">
              <div className="absolute -top-5 left-1/2 transform -translate-x-1/2">
                <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-full p-3 shadow-xl border-2 border-blue-300">
                  <Sparkles className="text-white" size={24} />
                </div>
              </div>

              <p className="text-blue-950 leading-relaxed text-left mt-4">
                {currentMessage}
              </p>

              {/* Detalhes decorativos */}
              <div className="flex justify-center gap-1.5 mt-8">
                {[...Array(7)].map((_, i) => (
                  <div
                    key={i}
                    className="w-2 h-2 rounded-full bg-gradient-to-r from-blue-500 to-blue-600"
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Mensagem inicial */}
        {!showMessage && (
          <p className="text-blue-200 italic animate-fadeIn text-lg">
            Clique no botão e receba uma mensagem de luz e axé
          </p>
        )}
      </div>

      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-fadeIn {
          animation: fadeIn 0.8s ease-out;
        }

        .animate-slideUp {
          animation: slideUp 0.7s ease-out;
        }
      `}</style>
    </div>
  );
}