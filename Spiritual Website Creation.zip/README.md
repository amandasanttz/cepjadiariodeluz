
  # Spiritual Website Creation

  This is a code bundle for Spiritual Website Creation. The original project is available at https://www.figma.com/design/G4t5RbS8zFT7XrgG6UMwFb/Spiritual-Website-Creation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  